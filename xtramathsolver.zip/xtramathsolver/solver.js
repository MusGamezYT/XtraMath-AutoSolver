(function() {
    'use-strict';

    console.log('XtraMath Auto-Solver Loaded. (Version 1.12 - Race Condition Fix)');

    // Configuration for the delay between clicking digits (in milliseconds)
    const CLICK_DELAY = 150; // Delay for stability
    
    // Global state variable to control if the solver should run
    let isSolverEnabled = false;

    // --- CRITICAL FIX: STATE FLAG TO PREVENT RACE CONDITIONS ---
    // If true, the script is currently clicking digits and should ignore the MutationObserver.
    let isTypingAnswer = false;

    // --- Setup and Initialization Functions ---

    /**
     * Loads the current solver state from Chrome storage.
     */
    function loadSolverState() {
        chrome.storage.local.get(['solverEnabled'], (result) => {
            isSolverEnabled = result.solverEnabled === true;
            console.log(`Solver initialized. Status: ${isSolverEnabled ? 'Enabled' : 'Disabled'}`);
        });
    }

    /**
     * Listener for messages from the popup (UI).
     */
    function setupMessageListener() {
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            if (request.action === "TOGGLE_SOLVER") {
                isSolverEnabled = request.enabled;
                console.log(`Solver state updated via message to: ${isSolverEnabled ? 'Enabled' : 'Disabled'}`);
            }
            // Acknowledge the message (required by Chrome)
            sendResponse({ status: "State updated" }); 
        });
    }


    /**
     * Finds the virtual keypad button corresponding to the given digit and clicks it.
     * @param {string} digit - The digit ('0' through '9') to click.
     * @returns {boolean} True if the button was found and clicked, false otherwise.
     */
    function clickKeypadButton(digit) {
        // Find the button whose text content exactly matches the digit
        const button = Array.from(document.querySelectorAll('button')).find(btn => btn.textContent.trim() === digit);

        if (button) {
            console.log(`Clicking keypad button: ${digit}`, button); 
            
            // Simulate a full mouse click event sequence for maximum compatibility
            button.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
            button.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
            button.dispatchEvent(new MouseEvent('click', { bubbles: true }));
            return true;
        }
        console.error(`Keypad button for digit ${digit} not found.`);
        return false;
    }

    /**
     * Tries to find and solve the math problem on the screen using keypad clicks.
     */
    function attemptSolve() {
        // --- PRIMARY GUARD CLAUSE: CHECK UI STATE ---
        if (!isSolverEnabled) {
            // console.log("Solver disabled by UI. Skipping run.");
            return;
        }

        // --- SECONDARY GUARD CLAUSE: Prevent script from running while it's in the middle of clicking an answer ---
        if (isTypingAnswer) {
            // console.log("Solver busy, ignoring new attempt.");
            return;
        }

        // --- Debug Log ---
        // console.log("Debug: attemptSolve() is running.");

        // --- Note: These selectors are very specific and may break if XtraMath updates its website ---
        const firstNumberParent = document.querySelector('.MuiBox-root.css-1wzifj2');
        const secondNumberParent = document.querySelector('.MuiBox-root.css-1en80zi');
        const operatorParent = document.querySelector('.MuiBox-root.css-17yh7mm');

        const firstNumberElement = firstNumberParent ? firstNumberParent.querySelector('.MuiTypography-root.MuiTypography-body1.css-1ha0g3v') : null;
        const secondNumberElement = secondNumberParent ? secondNumberParent.querySelector('.MuiTypography-root.MuiTypography-body1.css-1ha0g3v') : null;
        const operatorElement = operatorParent ? operatorParent.querySelector('.MuiTypography-root.MuiTypography-body1.css-1qdolyk') : null;

        // Only proceed if all elements were found
        if (firstNumberElement && secondNumberElement && operatorElement) {
            // Check if the input field already has a value (meaning we've already answered, or are waiting for new problem)
            const inputElement = document.querySelector('input');
            if (inputElement && inputElement.value.length > 0) {
                 return;
            }

            console.log('Problem elements found. Attempting to solve...');

            const num1 = parseInt(firstNumberElement.textContent, 10);
            const num2 = parseInt(secondNumberElement.textContent, 10);
            const operatorText = operatorElement.textContent.trim();
            let operator;

            // Handle visual operators (×, ÷, −)
            switch (operatorText) {
                case '+': operator = '+'; break;
                case '-':
                case '−': // Minus sign (U+2212)
                    operator = '-';
                    break;
                case '*':
                case 'x':
                case 'X':
                case '×': // Multiplication sign (U+00D7)
                    operator = '*';
                    break;
                case '/':
                case '÷': // Division sign (U+00F7)
                    operator = '/';
                    break;
                default:
                    console.log('Unknown operator text:', operatorText);
                    return;
            }

            console.log(`Parsed problem: ${num1} ${operator} ${num2}`);

            let finalAnswer;

            // --- Calculation Logic ---
            switch (operator) {
                case '+': finalAnswer = Math.floor(num1 + num2); break;
                case '-': finalAnswer = Math.floor(num1 - num2); break;
                case '*': finalAnswer = Math.floor(num1 * num2); break;
                case '/':
                    if (num2 === 0) {
                        console.error("Error: Division by zero encountered.");
                        return;
                    }
                    finalAnswer = Math.round(num1 / num2); 
                    break;
                default:
                    console.error("Internal error: Unknown operator after parsing.");
                    return;
            }

            if (isNaN(finalAnswer) || !isFinite(finalAnswer)) {
                console.log('Calculation result is invalid. Aborting.');
                return;
            }

            const resultString = finalAnswer.toString();
            console.log('Calculated Result:', resultString);

            // Set the busy flag immediately
            isTypingAnswer = true;
            
            // --- 1. Enter the digits by clicking the keypad buttons ---
            const digits = resultString.split('');
            let delay = 0;

            digits.forEach((digit) => {
                // Schedule each click with an increasing delay
                setTimeout(() => {
                    clickKeypadButton(digit);
                }, delay);
                delay += CLICK_DELAY;
            });
            
            // --- 2. CRITICAL: Unset the busy flag after all clicks have finished ---
            // Add a buffer time (CLICK_DELAY * 2) to ensure the last click event completes before allowing a re-run.
            setTimeout(() => {
                isTypingAnswer = false;
                console.log("Typing complete. Solver is now ready for the next problem.");
            }, delay + (CLICK_DELAY * 2)); 
        } else {
             // console.log("Debug: Could not find problem elements. Selectors may be outdated.");
        }
    }

    // --- Main Logic ---

    // 1. Use MutationObserver instead of setInterval for efficiency
    const observer = new MutationObserver((mutations) => {
        // Debounce the changes to avoid running the solver multiple times for small DOM updates
        let timer;
        clearTimeout(timer);
        timer = setTimeout(attemptSolve, 100); 
    });

    // 2. Start observing the main body of the page for any changes
    observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true // Check attributes too, as class names change
    });
    
    // 3. Initialize extension state
    loadSolverState();
    setupMessageListener();

    // 4. Run an initial check in case the page is already loaded
    setTimeout(attemptSolve, 500);

})();