document.addEventListener('DOMContentLoaded', () => {
    const toggle = document.getElementById('solver-toggle');
    const statusDisplay = document.getElementById('status-display');

    // 1. Load the current state when the popup opens
    chrome.storage.local.get(['solverEnabled'], (result) => {
        const isEnabled = result.solverEnabled === true;
        toggle.checked = isEnabled;
        updateStatus(isEnabled);
    });

    // 2. Add listener to save the new state when the toggle changes
    toggle.addEventListener('change', () => {
        const isEnabled = toggle.checked;
        
        // Save the state in Chrome's local storage
        chrome.storage.local.set({ solverEnabled: isEnabled }, () => {
            console.log(`Solver is now set to: ${isEnabled ? 'Enabled' : 'Disabled'}`);
            updateStatus(isEnabled);
        });
        
        // Send a message to the content script (solver.js) to immediately update
        // its state without waiting for the next problem
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
            if (tabs[0].url.includes("xtramath.org/app/student/practice")) {
                chrome.tabs.sendMessage(tabs[0].id, { action: "TOGGLE_SOLVER", enabled: isEnabled });
            }
        });
    });

    // Function to update the text display
    function updateStatus(isEnabled) {
        statusDisplay.textContent = isEnabled ? 'ON' : 'OFF';
        statusDisplay.classList.remove('on', 'off');
        statusDisplay.classList.add(isEnabled ? 'on' : 'off');
    }
});